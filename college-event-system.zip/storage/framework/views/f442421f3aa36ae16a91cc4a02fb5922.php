<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <h3><?php echo e($event->title); ?></h3>
    <p><?php echo e($event->description); ?></p>
    <p><strong>Date:</strong> <?php echo e($event->date); ?> <strong>Time:</strong> <?php echo e($event->time); ?></p>
    <p><strong>Venue:</strong> <?php echo e($event->venue); ?></p>
    <p><strong>Seats:</strong> <?php echo e($event->seats_booked); ?>/<?php echo e($event->max_participants); ?></p>
    <?php if(auth()->guard()->check()): ?>
      <form method="POST" action="<?php echo e(route('events.register', $event->id)); ?>"><?php echo csrf_field(); ?><button class="btn btn-primary">Register</button></form>
    <?php else: ?>
      <a href="/login" class="btn btn-outline-primary">Login to register</a>
    <?php endif; ?>
    <hr>
    <a href="data:text/calendar;charset=utf8,BEGIN:VCALENDAR%0ASUMMARY:<?php echo e(urlencode($event->title)); ?>%0ADTSTART:<?php echo e($event->date); ?>T<?php echo e(str_replace(':','',$event->time)); ?>%0ALOCATION:<?php echo e(urlencode($event->venue)); ?>%0AEND:VCALENDAR" download="event.ics" class="btn btn-sm btn-outline-secondary">Add to Calendar</a>
    <div class="mt-2">
      <span>Share:</span>
      <a target="_blank" href="https://wa.me/?text=<?php echo e(urlencode($event->title.' on '.$event->date)); ?>">WhatsApp</a> |
      <a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(request()->fullUrl())); ?>">Facebook</a> |
      <a target="_blank" href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo e(urlencode(request()->fullUrl())); ?>&title=<?php echo e(urlencode($event->title)); ?>">LinkedIn</a>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\college-event-system\resources\views/events/show.blade.php ENDPATH**/ ?>