<?php $__env->startSection('content'); ?>
<h2>Organizer Dashboard</h2>
<h4>Your Events</h4>
<ul>
  <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($ev->title); ?> - Status: <?php echo e($ev->status); ?></li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\college-event-system\resources\views/dashboards/organizer.blade.php ENDPATH**/ ?>