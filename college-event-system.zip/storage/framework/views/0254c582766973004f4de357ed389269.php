<?php $__env->startSection('content'); ?>
<h2>Sitemap</h2>
<ul>
  <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
  <li><a href="/dashboard">Dashboard</a></li>
  <li><a href="/gallery">Gallery</a></li>
  <li><a href="/my-certificates">Certificates</a></li>
  <li><a href="/reports/csv">Reports</a></li>
  <li><a href="/notifications">Notifications</a></li>
  <li><a href="/sitemap">Sitemap</a></li>
</ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\college-event-system\resources\views/sitemap.blade.php ENDPATH**/ ?>