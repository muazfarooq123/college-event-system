<?php $__env->startSection('content'); ?>
<?php if(isset($events)): ?>
  <div class="list-group">
    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="<?php echo e(route('events.show', $event->id)); ?>" class="list-group-item list-group-item-action">
        <div class="d-flex w-100 justify-content-between">
          <h5 class="mb-1"><?php echo e($event->title); ?></h5>
          <small><?php echo e($event->date); ?></small>
        </div>
        <p class="mb-1"><?php echo e(Str::limit($event->description, 120)); ?></p>
        <small>Venue: <?php echo e($event->venue); ?> | Seats: <?php echo e($event->seats_booked); ?>/<?php echo e($event->max_participants); ?></small>
      </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="mt-3"><?php echo e($events->links() ?? ''); ?></div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\college-event-system\resources\views/events/index.blade.php ENDPATH**/ ?>