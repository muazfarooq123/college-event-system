<p>Your two-factor authentication code is: <strong>{{ $user->two_factor_code }}</strong></p>
<p>This code will expire in 10 minutes.</p>