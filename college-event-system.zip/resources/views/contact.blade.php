@extends('layouts.app')
@section('content')
<h2>Contact Us</h2>
<p>For support or queries, email us at <a href="mailto:support@collegeevents.com">support@collegeevents.com</a> or call +92-123-4567890.</p>
@endsection
